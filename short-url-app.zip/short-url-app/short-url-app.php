<?php
/*
Plugin Name: Short URL App
Description: A plugin to create and manage short URLs.
Version: 1.0
Author: Araii.ID | use [short_url_form] on your page
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Create a custom table for storing short URLs
function sua_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'short_urls';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        long_url text NOT NULL,
        short_code varchar(100) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY short_code (short_code)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'sua_create_table');

// Generate a short code
function sua_generate_short_code($length = 6) {
    return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);
}

// Shortcode form in the frontend
function sua_shortcode_form() {
    if (isset($_POST['sua_long_url'])) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'short_urls';

        $long_url = esc_url_raw($_POST['sua_long_url']);
        $short_code = sua_generate_short_code();

        // Check if the shortcode already exists
        $existing_short_code = $wpdb->get_var($wpdb->prepare("SELECT short_code FROM $table_name WHERE short_code = %s", $short_code));
        while ($existing_short_code) {
            $short_code = sua_generate_short_code();
            $existing_short_code = $wpdb->get_var($wpdb->prepare("SELECT short_code FROM $table_name WHERE short_code = %s", $short_code));
        }

        // Insert the new short URL into the database
        $wpdb->insert(
            $table_name,
            array(
                'long_url' => $long_url,
                'short_code' => $short_code
            )
        );

        $short_url = home_url('/' . $short_code);
        echo '<p>Short URL: <a href="' . esc_url($short_url) . '">' . esc_url($short_url) . '</a></p>';
    }

    ob_start();
    ?>
    <form method="post" action="">
        <label for="sua_long_url">Enter a URL to shorten:</label>
        <input type="url" id="sua_long_url" name="sua_long_url" required>
        <input type="submit" value="Generate Short URL">
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode('short_url_form', 'sua_shortcode_form');

// Handle short URL redirection
function sua_handle_redirect() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'short_urls';

    $request = trim($_SERVER['REQUEST_URI'], '/');
    $short_code = sanitize_text_field($request);

    if (!empty($short_code)) {
        $long_url = $wpdb->get_var($wpdb->prepare("SELECT long_url FROM $table_name WHERE short_code = %s", $short_code));
        if ($long_url) {
            wp_redirect($long_url, 301);
            exit;
        }
    }
}
add_action('template_redirect', 'sua_handle_redirect');